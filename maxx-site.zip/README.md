# MAXX Cleaning (React + Vite + TypeScript + Tailwind)

## Quickstart
```bash
npm install
npm run dev
```
Open the printed local URL.

## Build
```bash
npm run build
npm run preview
```
