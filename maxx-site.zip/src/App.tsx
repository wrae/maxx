import React, { useEffect, useRef, useState } from "react";

export const I18nContext = React.createContext<{
  t: (k: string) => any;
  lang: 'en' | 'es';
  setLang: (l: 'en' | 'es') => void;
}>({ t: (k)=>k, lang: 'en', setLang: ()=>{} });

import { BrowserRouter, Routes, Route, NavLink, Link, useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Services from "./pages/Services";
import Pricing from "./pages/Pricing";
import About from "./pages/About";
import Contact from "./pages/Contact";

const NAVY = "#0C2C3E";
const GOLD = "#E7C664";

const IMAGES = [
  "https://images.unsplash.com/photo-1581578731548-c64695cc6952?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1581579188871-45ea61f2a0c8?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1587017539504-67cfbddac569?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1563453392212-326f5e854473?q=80&w=1600&auto=format&fit=crop"
];

function HeaderCarousel(){
  const { t } = React.useContext(I18nContext);
  const [i, setI] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setI((x)=> (x+1) % IMAGES.length), 5000);
    return () => clearInterval(id);
  }, []);
  return (
    <div className="relative h-[42vh] min-h-[260px] w-full overflow-hidden">
      {IMAGES.map((src, idx) => (
        <img key={src} src={src} alt="Cleaning service in action"
             className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${idx===i?"opacity-100":"opacity-0"}`} />
      ))}
      <div className="absolute inset-0 bg-black/35" />
      <div className="absolute left-6 top-6 sm:left-8 sm:top-8">
        <img src="/maxx-logo.jpg" alt="MAXX Painting and Cleaning" className="h-14 sm:h-20 rounded-md object-contain" />
      </div>
      <div className="absolute inset-x-0 bottom-8 mx-auto max-w-6xl px-4 text-white">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">{t("hero.title")}</h1>
        <p className="mt-2 max-w-2xl opacity-90">{t("hero.subtitle")}</p>
        <a href="/contact" className="mt-4 inline-block rounded-2xl bg-white/95 px-5 py-3 text-gray-900 shadow hover:bg-white">{t("hero.cta")} →</a>
      </div>
      <div className="absolute bottom-3 right-4 flex gap-2">
        {IMAGES.map((_, idx)=> (
          <button key={idx} aria-label={`Go to slide ${idx+1}`} onClick={()=>setI(idx)}
            className={`h-2.5 w-2.5 rounded-full ${idx===i?"bg-white w-6":"bg-white/60"}`} />
        ))}
      </div>
    </div>
  );
}

function Footer(){
  return (
    <footer className="mt-12 border-t border-black/10 py-8" style={{background:"#0C2C3E"}}>
      <div className="mx-auto max-w-6xl px-4 text-white/90 text-sm">
        © {new Date().getFullYear()} MAXX Painting & Cleaning LLC • Insured & bonded • (555) 123-4567
      </div>
    </footer>
  );
}



type Lang = "en" | "es";
const NAV = [
  { to: "/", key: "home", label: { en: "Home", es: "Inicio" } },
  { to: "/services", key: "services", label: { en: "Services", es: "Servicios" } },
  { to: "/pricing", key: "pricing", label: { en: "Pricing", es: "Precios" } },
  { to: "/about", key: "about", label: { en: "About", es: "Nosotros" } },
  { to: "/contact", key: "contact", label: { en: "Contact Us", es: "Contáctenos" } },
];

function HeaderHero(){
  return (
    <header className="relative w-full">
      {/* Minimal hero area */}
      <div className="h-[42vh] min-h-[260px] w-full bg-slate-500/20" />
      {/* Single logo (served from public/) */}
      <img
        src="/maxx-logo.jpg"
        alt="MAXX logo"
        className="absolute left-4 top-4 h-16 w-auto md:left-6 md:top-6 md:h-20 lg:left-8 lg:top-8 lg:h-24 select-none pointer-events-none"
      />
    </header>
  );
}

function Navbar({ lang, onToggleLang, onOpenMobile }:{ lang: Lang; onToggleLang: ()=>void; onOpenMobile: ()=>void; }){
  return (
    <nav aria-label="Main" className="sticky top-0 z-30 w-full outline-none" style={{ background: NAVY }}>
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <div className="w-6 md:w-8" aria-hidden />
        <ul className="hidden gap-6 md:flex">
          {NAV.map(n => (
            <li key={n.key}>
              <NavLink
                to={n.to}
                className={({ isActive }) =>
                  `rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
                    isActive ? "bg-amber-300 text-black" : "text-white hover:text-gray-200"
                  }`
                }
                style={{ wordSpacing: "2px", letterSpacing: "0.02em" }}
              >
                {n.label[lang]}
              </NavLink>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleLang}
            className="rounded-2xl border border-white/40 px-3 py-1.5 text-white hover:bg-white/10"
            aria-label="Toggle language"
          >
            {lang === "en" ? "ES" : "EN"}
          </button>
          <button
            onClick={onOpenMobile}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/40 text-white md:hidden"
            aria-label="Open menu"
          >
            <span className="sr-only">Open menu</span>
            <div className="flex flex-col gap-1.5">
              <span className="block h-0.5 w-5 bg-white" />
              <span className="block h-0.5 w-5 bg-white" />
              <span className="block h-0.5 w-5 bg-white" />
            </div>
          </button>
        </div>
      </div>
    </nav>
  );
}

function MobileMenu({ open, onClose, lang }:{ open: boolean; onClose: ()=>void; lang: Lang; }){
  const location = useLocation();
  const first = useRef(true);
  useEffect(() => {
    if (first.current){ first.current = false; return; }
    onClose();
  }, [location.pathname]); // eslint-disable-line

  if (!open) return null;
  return (
    <div className="md:hidden" role="dialog" aria-modal="true">
      <div className="fixed inset-0 bg-black/25" onClick={onClose} />
      <div className="absolute left-3 right-3 top-[70px] rounded-2xl shadow-lg ring-1 ring-black/5" style={{ background: NAVY }}>
        <ul className="px-2 py-2">
          {NAV.map(n => (
            <li key={n.key}>
              <Link to={n.to} className="block rounded-xl px-3 py-2 text-base font-medium text-white hover:bg-white/10">
                {n.label[lang]}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Shell() {
  const { t, lang, setLang } = React.useContext(I18nContext);
  const [open, setOpen] = React.useState(false);
  const toggleLang = () => setLang(lang === 'en' ? 'es' : 'en');

  return (
    <>
      <header className="w-full" style={{ background: NAVY }}>
        <HeaderCarousel />
        <Navbar
          lang={lang}
          t={t}
          onToggleLang={toggleLang}
          onOpenMobile={() => setOpen(true)}
        />
        <MobileMenu open={open} onClose={() => setOpen(false)} t={t} />
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>

      <Footer />
    </>
  );
}

